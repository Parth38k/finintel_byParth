"""Build funds.json from MFapi.in.

MFapi is a free API that provides NAV history and latest NAV for Indian mutual fund schemes.
Docs: https://www.mfapi.in/docs/

Why this script exists:
- A GitHub Pages site is static, so you typically keep a precomputed `data/funds.json` in your repo.
- This script helps you generate that JSON (and you can run it via GitHub Actions for free).

Important:
- Computing 1Y / 3Y CAGR / 5Y CAGR for ~1400 funds needs NAV history.
- Doing it for *all* schemes can be slow. Prefer a curated universe of scheme codes.

Usage:
- Put a list of scheme codes in `data/fund_universe_codes.json` (e.g., [125497, 120503, ...]).
- Run: python scripts/build_funds.py
"""

import json
import datetime
from pathlib import Path

import requests

OUT = Path("data") / "funds.json"
UNIVERSE = Path("data") / "fund_universe_codes.json"

BASE = "https://api.mfapi.in/mf"

def cagr(nav_start, nav_end, years):
    if nav_start <= 0 or nav_end <= 0 or years <= 0:
        return None
    return ((nav_end / nav_start) ** (1 / years) - 1) * 100

def fetch_json(url, timeout=30):
    r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    return r.json()

def nearest_nav(points_desc, target_date):
    """Return NAV closest on-or-before target_date.
    points_desc must be sorted descending by date (newest first).
    """
    for p in points_desc:
        dt = datetime.datetime.strptime(p["date"], "%d-%m-%Y").date()
        if dt <= target_date:
            return float(p["nav"])
    return None

def main():
    if UNIVERSE.exists():
        codes = json.loads(UNIVERSE.read_text(encoding="utf-8"))
    else:
        # Demo fallback: grab first 200 schemes (not the 1400+ universe you want)
        listing = fetch_json(f"{BASE}?page=1&per_page=200")
        codes = [x["schemeCode"] for x in listing.get("data", [])]

    out = []
    today = datetime.date.today()

    for code in codes:
        try:
            d = fetch_json(f"{BASE}/{code}")
            meta = d.get("meta", {})
            name = meta.get("scheme_name", "")
            amc = meta.get("fund_house", "")
            hist = d.get("data", [])

            def key(p):
                return datetime.datetime.strptime(p["date"], "%d-%m-%Y").date()

            hist_desc = sorted(hist, key=key, reverse=True)
            if not hist_desc:
                continue

            nav_now = float(hist_desc[0]["nav"])
            nav_1y = nearest_nav(hist_desc, today.replace(year=today.year - 1))
            nav_3y = nearest_nav(hist_desc, today.replace(year=today.year - 3))
            nav_5y = nearest_nav(hist_desc, today.replace(year=today.year - 5))

            ret1y = ((nav_now / nav_1y) - 1) * 100 if nav_1y else None
            cagr3 = cagr(nav_3y, nav_now, 3) if nav_3y else None
            cagr5 = cagr(nav_5y, nav_now, 5) if nav_5y else None

            out.append(
                {
                    "code": int(code),
                    "name": name,
                    "amc": amc,
                    "category": "Uncategorised",  # fill from your mapping
                    "aumCr": None,  # fill if you have a source
                    "minSip": None,  # fill if you have a source
                    "rating": None,  # compute your own rating or ingest
                    "ret1y": ret1y,
                    "cagr3y": cagr3,
                    "cagr5y": cagr5,
                    "vol3y": None,
                    "maxdd": None,
                }
            )
        except Exception as e:
            print("Failed", code, e)

    OUT.write_text(
        json.dumps({"data": out, "updatedAt": datetime.datetime.utcnow().isoformat() + "Z"}, indent=2),
        encoding="utf-8",
    )
    print("Wrote", OUT, "rows:", len(out))

if __name__ == "__main__":
    main()
